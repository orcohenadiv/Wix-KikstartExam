const fs = require('fs').promises;

const getAllTickets = async (req, res) => {
    try {
        const data = await fs.readFile('data.json', 'utf8');
        const tickets = JSON.parse(data);
        res.json(tickets);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

const filterTicketsByTime = async (req, res) => {
    const { from, to } = req.query;

    if (!from && !to) {
        res.status(400).json({ error: 'Missing time range parameters' });
        return;
    }

    try {
        const data = await fs.readFile('data.json', 'utf8');
        const tickets = JSON.parse(data);
        let filteredTickets = tickets;

        if (from) {
            filteredTickets = filteredTickets.filter(
                (ticket) => ticket.creationTime >= from
            );
        }

        if (to) {
            filteredTickets = filteredTickets.filter(
                (ticket) => ticket.creationTime <= to
            );
        }

        res.json(filteredTickets);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

const filterTicketsBySearch = async (req, res) => {
    const { title, content, email } = req.query;

    if (!title && !content && !email) {
        res.status(400).json({ error: 'Missing search parameters' });
        return;
    }

    try {
        const data = await fs.readFile('data.json', 'utf8');
        const tickets = JSON.parse(data);
        const filteredTickets = tickets.filter((ticket) =>
            (title && ticket.title.toLowerCase().includes(title.toLowerCase())) ||
            (content && ticket.content.toLowerCase().includes(content.toLowerCase())) ||
            (email && ticket.userEmail.toLowerCase().includes(email.toLowerCase()))
        );
        res.json(filteredTickets);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports = {
    getAllTickets,
    filterTicketsByTime,
    filterTicketsBySearch,
};
