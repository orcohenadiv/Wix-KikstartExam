const express = require('express');
const app = express();

const ticketRoutes = require('./routes/ticketsRoute');

app.use(express.json());
app.use('/tickets', ticketRoutes);

module.exports = app;




