const express = require('express');
const router = express.Router();

const {
  getAllTickets,
  filterTicketsByTime,
  filterTicketsBySearch,
} = require('../controllers/ticketsController');

router.get('/', getAllTickets);
router.get('/time', filterTicketsByTime);
router.get('/search', filterTicketsBySearch);

module.exports = router;
