const request = require('supertest');
const app = require('../app');

const title = 'Need a Little Help with Your Site? Hire a Corvid Web Developer'
const content = 'Here at Wix we strive to support you with this community forum, API references, articles, videos and code examples. But sometimes you might need a little extra help to get your site exactly the way you want it. \nHire a developer from the Wix Arena, an online marketplace with top Corvid web developers from around the world. Submit your project details here, and we’ll find the right professional for you.'
const email = 'jug@nesetal.af'
const fromTime = '1542111235543'
const toTime = '1542111235545'

describe('GET /tickets', () => {
    it('should return all tickets', async () => {
        const response = await request(app).get('/tickets');
        expect(response.status).toBe(200);
        expect(response.body.length).toBeGreaterThan(0);
    });
});

describe('GET /tickets/time', () => {
    it('should return filtered tickets by time (from)', async () => {
        const response = await request(app)
            .get('/tickets/time')
            .query({ from: fromTime });
        expect(response.status).toBe(200);
        expect(response.body.length).toBeGreaterThan(0);
    });

    it('should return filtered tickets by time (to)', async () => {
        const response = await request(app)
            .get('/tickets/time')
            .query({ to: toTime });
        expect(response.status).toBe(200);
        expect(response.body.length).toBeGreaterThan(0);
    });

    it('should return filtered tickets by time (from and to)', async () => {
        const response = await request(app)
            .get('/tickets/time')
            .query({ from: fromTime, to: toTime });
        expect(response.status).toBe(200);
        expect(response.body.length).toBeGreaterThan(0);
    });

    it('should return 400 if no time range parameters are provided', async () => {
        const response = await request(app).get('/tickets/time');
        expect(response.status).toBe(400);
        expect(response.body).toHaveProperty('error', 'Missing time range parameters');
    });
});

describe('GET /tickets/search', () => {
    it('should return filtered tickets by title', async () => {
        const response = await request(app).get('/tickets/search').query({ title: title });
        expect(response.status).toBe(200);
        expect(response.body.length).toBeGreaterThan(0);
    });

    it('should return filtered tickets by content', async () => {
        const response = await request(app)
            .get('/tickets/search')
            .query({ content: content });
        expect(response.status).toBe(200);
        expect(response.body.length).toBeGreaterThan(0);
    });

    it('should return filtered tickets by email', async () => {
        const response = await request(app).get('/tickets/search').query({ email: email });
        expect(response.status).toBe(200);
        expect(response.body.length).toBeGreaterThan(0);
    });

    it('should return 400 if no search parameters are provided', async () => {
        const response = await request(app).get('/tickets/search');
        expect(response.status).toBe(400);
        expect(response.body).toHaveProperty('error', 'Missing search parameters');
    });
});